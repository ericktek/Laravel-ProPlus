<h2>Hey, It's me {{ $data->full_name }}</h2>
<br>

<strong>User details: </strong><br>
<strong>Name: </strong>{{ $data->full_name }} <br>
<strong>Email: </strong>{{ $data->email }} <br>
<strong>Phone: </strong>{{ $data->phone }} <br>
<strong>Message: </strong>{{ $data->message }} <br><br>

Thank you
