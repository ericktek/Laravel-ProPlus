<?php $__env->startSection('content'); ?>
    <!----slideshow Section-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
        <div class="container-fluid">
            <div class="navbar-padding"> <a class="navbar-brand" href="/"><img src="<?php echo e(asset('images/logo.png')); ?>"
                        style="width: 50px; height: 50px;" alt="nav-logo"></a>
                <a class="navbar-brand" href="/"><img src="<?php echo e(asset('images/logo-name.png')); ?>"
                        style="width: 150px; height: 25px;" alt="nav-logo"></a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link active" href="contact" tabindex="-1" aria-disabled="true"> <i
                                class="bi bi-person-lines-fill"> Contacts</i></a>
                    </li>
                </ul>
                <form class="d-flex">
                    <?php if(Route::has('login')): ?>
                        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                            <?php if(auth()->guard()->check()): ?>
                                <button class="btn btn-outline-success">
                                    <a href="<?php echo e(url('/dashboard')); ?>" class="admin"
                                        class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
                                </button>
                            <?php else: ?>
                                <button class="btn btn-outline-success">
                                    <a class="admin" href="<?php echo e(route('login')); ?>"
                                        class="text-sm text-gray-700 dark:text-gray-500 underline">Admin</a>
                                </button>
                                <?php if(Route::has('register')): ?>
                                    
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </nav>

    <div style="margin-top: 25px; margin-bottom: 25px;" class="container">
        <h1>Products</h1>
        <a style="color: green; text-decoration: none;" href="contact">Let know what's can i help you to day </a>
        <div class=""row>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div style="margin-top: 25px;" class="card" style="width: 18rem;">
                        <img class="card-img-top" style="object-fit: cover;" src="<?php echo e(Storage::url($post->featured_image)); ?>"
                            alt="<?php echo e($post->title); ?>">
                        <div class="card-body">
                            <h4 class="card-title" style="color: green; font-weight: 700;">
                                <?php echo e($post->title); ?></h4>
                            <p class="card-text"><?php echo e($post->content); ?></p>
                            <a style="text-decoration: none; background-color: white; border-radius: 2px solid green; border-radius: 2px; border: 1px solid green; color: green"
                                class="btn btn-primary custom-btn">Created
                                at: <?php echo e($post->created_at); ?></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test5\resources\views/product.blade.php ENDPATH**/ ?>