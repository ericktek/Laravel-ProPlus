<img src="<?php echo e(asset('images/logo.png')); ?>"alt="logo" height="50px" width="60px">
<?php /**PATH C:\xampp\htdocs\test5\resources\views/components/application-logo.blade.php ENDPATH**/ ?>