<h2>Hey, It's me <?php echo e($data->full_name); ?></h2>
<br>

<strong>User details: </strong><br>
<strong>Name: </strong><?php echo e($data->full_name); ?> <br>
<strong>Email: </strong><?php echo e($data->email); ?> <br>
<strong>Phone: </strong><?php echo e($data->phone); ?> <br>
<strong>Message: </strong><?php echo e($data->message); ?> <br><br>

Thank you
<?php /**PATH C:\xampp\htdocs\test5\resources\views/emails/contact.blade.php ENDPATH**/ ?>